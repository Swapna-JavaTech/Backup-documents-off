const http =  require('http');
const fs = require('fs');

const server = http.createServer(function(request,res){
        //res.end("Hello from fileupload")
        if (request.url === "/upload" && request.method === "POST") {
            let body = "";
            request.on("data", chunk => {
              body += chunk;
            });
            request.on("end", () => {
              fs.writeFile("myFile.txt", body, err => {
                if (err) {
                  res.statusCode = 500;
                  res.end("Error: " + err.message);
                } else {
                  res.statusCode = 200;
                  res.end("File uploaded");
                }
              });
            });
          } else {
            res.statusCode = 404;
            res.end("file not found");
          }
})

server.listen(5050,function(){
    console.log("Server started with port no 5050")
});